-- ============================================================
-- SEED DATA - Sistema de Gestión de Préstamos
-- ============================================================

-- ROLES
INSERT INTO `roles` (`id`, `name`, `slug`, `description`) VALUES
(1, 'SuperAdmin', 'superadmin', 'Acceso total al sistema y configuración'),
(2, 'Admin',      'admin',      'Gestión de clientes, préstamos y usuarios'),
(3, 'Asesor',     'asesor',     'Cartera asignada, registro de pagos'),
(4, 'Cliente',    'cliente',    'Solo ver sus préstamos y documentos');

-- SUPERADMIN (password: Admin@1234)
INSERT INTO `users` (`role_id`, `name`, `email`, `password`, `phone`, `is_active`) VALUES
(1, 'Super Administrador', 'superadmin@prestamos.hn', '$2y$12$hN0VJx3jlVCk0i2cj7zH2OW6c1cRoqhI6L2hXF2wGfnCp.Nh6y4oO', '+504 9999-0000', 1),
(2, 'Admin Demo',          'admin@prestamos.hn',      '$2y$12$hN0VJx3jlVCk0i2cj7zH2OW6c1cRoqhI6L2hXF2wGfnCp.Nh6y4oO', '+504 9999-0001', 1),
(3, 'Asesor Demo',         'asesor@prestamos.hn',     '$2y$12$hN0VJx3jlVCk0i2cj7zH2OW6c1cRoqhI6L2hXF2wGfnCp.Nh6y4oO', '+504 9999-0002', 1);
-- NOTA: password hash corresponde a 'Admin@1234'

-- CONFIGURACIÓN INICIAL
INSERT INTO `settings` (`setting_key`, `setting_value`, `setting_type`, `description`, `group`) VALUES
('app_name',              'SistemaPréstamos',     'string',  'Nombre del sistema',                           'general'),
('app_currency',          'L',                    'string',  'Símbolo de moneda',                            'general'),
('app_currency_name',     'Lempira',              'string',  'Nombre de la moneda',                          'general'),
('default_late_fee_rate', '0.05',                 'decimal', 'Tasa moratoria mensual por defecto (5%)',       'loans'),
('grace_days',            '3',                    'integer', 'Días de gracia antes de aplicar mora',         'loans'),
('alert_days_upcoming',   '7',                    'integer', 'Días para alerta "por vencer"',                'dashboard'),
('alert_days_warning',    '15',                   'integer', 'Días aviso previo',                            'dashboard'),
('initial_capital',       '200000.00',            'decimal', 'Capital inicial para proyección (L)',          'reports'),
('max_upload_size_mb',    '10',                   'integer', 'Tamaño máximo de archivo en MB',               'documents'),
('allowed_mime_types',    '["application/pdf","image/jpeg","image/png","image/webp"]', 'json', 'MIME permitidos', 'documents'),
('loan_number_prefix',    'PRES-',                'string',  'Prefijo para número de préstamo',              'loans'),
('client_number_prefix',  'CLI-',                 'string',  'Prefijo para código de cliente',               'clients'),
('payment_number_prefix', 'PAG-',                 'string',  'Prefijo para número de pago',                  'loans'),
('items_per_page',        '20',                   'integer', 'Registros por página en tablas',               'general'),
('timezone',              'America/Tegucigalpa',  'string',  'Zona horaria del servidor',                    'general');

-- CLIENTE DEMO
INSERT INTO `clients` (`code`, `first_name`, `last_name`, `identity_number`, `email`, `phone`, `address`, `city`, `is_active`, `created_by`) VALUES
('CLI-00001', 'Juan',   'Pérez López',    '0801-1990-12345', 'juan@demo.hn', '+504 9811-1111', 'Col. Kennedy, Casa #5', 'Tegucigalpa', 1, 1),
('CLI-00002', 'María',  'García Sánchez', '0801-1985-67890', 'maria@demo.hn','+504 9822-2222', 'Bo. El Centro',         'San Pedro Sula', 1, 1),
('CLI-00003', 'Carlos', 'Martínez Ruiz',  '0801-1978-11122', null,           '+504 9833-3333', 'Col. Palmira',          'Tegucigalpa', 1, 1);
