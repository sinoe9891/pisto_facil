-- ============================================================
-- Sistema de Gestión de Préstamos - Schema MySQL 8+
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET sql_mode = 'STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -------------------------------------------------------
-- ROLES
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `roles` (
  `id` TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(50) NOT NULL,
  `slug` VARCHAR(50) NOT NULL,
  `description` VARCHAR(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- USUARIOS
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id` TINYINT UNSIGNED NOT NULL DEFAULT 3,
  `name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(180) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `avatar` VARCHAR(255) DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `remember_token` VARCHAR(100) DEFAULT NULL,
  `password_reset_token` VARCHAR(100) DEFAULT NULL,
  `password_reset_expires` DATETIME DEFAULT NULL,
  `last_login` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `idx_users_role` (`role_id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- CLIENTES
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `clients` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED DEFAULT NULL COMMENT 'Linked user account if client role',
  `assigned_to` INT UNSIGNED DEFAULT NULL COMMENT 'Asesor/Cobrador asignado',
  `code` VARCHAR(20) NOT NULL COMMENT 'Código interno',
  `first_name` VARCHAR(100) NOT NULL,
  `last_name` VARCHAR(100) NOT NULL,
  `identity_number` VARCHAR(30) DEFAULT NULL COMMENT 'DNI/RTN',
  `email` VARCHAR(180) DEFAULT NULL,
  `phone` VARCHAR(20) DEFAULT NULL,
  `phone2` VARCHAR(20) DEFAULT NULL,
  `address` TEXT DEFAULT NULL,
  `city` VARCHAR(100) DEFAULT NULL,
  `occupation` VARCHAR(100) DEFAULT NULL,
  `monthly_income` DECIMAL(12,2) DEFAULT NULL,
  `reference_name` VARCHAR(150) DEFAULT NULL,
  `reference_phone` VARCHAR(20) DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  `created_by` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_clients_code` (`code`),
  KEY `idx_clients_user` (`user_id`),
  KEY `idx_clients_assigned` (`assigned_to`),
  KEY `idx_clients_name` (`last_name`, `first_name`),
  CONSTRAINT `fk_clients_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_clients_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_clients_created` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- DOCUMENTOS DE CLIENTES
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `client_documents` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` INT UNSIGNED NOT NULL,
  `doc_type` ENUM('letra_cambio','pagare','identidad','contrato','evidencia','otro') NOT NULL,
  `original_name` VARCHAR(255) NOT NULL,
  `stored_name` VARCHAR(255) NOT NULL,
  `path` VARCHAR(500) NOT NULL,
  `mime_type` VARCHAR(100) NOT NULL,
  `file_size` INT UNSIGNED NOT NULL COMMENT 'Bytes',
  `file_hash` VARCHAR(64) NOT NULL COMMENT 'SHA-256',
  `description` VARCHAR(255) DEFAULT NULL,
  `uploaded_by` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_docs_client` (`client_id`),
  KEY `idx_docs_type` (`doc_type`),
  CONSTRAINT `fk_docs_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_docs_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- PRÉSTAMOS
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `loans` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` INT UNSIGNED NOT NULL,
  `assigned_to` INT UNSIGNED DEFAULT NULL,
  `created_by` INT UNSIGNED NOT NULL,
  `loan_number` VARCHAR(20) NOT NULL,
  `loan_type` ENUM('A','B','C') NOT NULL COMMENT 'A=Nivelada, B=Variable/Abonos, C=Simple Mensual',
  `principal` DECIMAL(14,2) NOT NULL COMMENT 'Monto desembolsado',
  `interest_rate` DECIMAL(7,4) NOT NULL COMMENT 'Tasa (mensual si type C, anual si A)',
  `rate_type` ENUM('monthly','annual') NOT NULL DEFAULT 'monthly',
  `term_months` TINYINT UNSIGNED DEFAULT NULL COMMENT 'Plazo en meses (requerido para tipo A)',
  `late_fee_rate` DECIMAL(7,4) NOT NULL DEFAULT 0.0500 COMMENT 'Tasa moratoria mensual',
  `grace_days` TINYINT UNSIGNED NOT NULL DEFAULT 0 COMMENT 'Días de gracia antes de mora',
  `disbursement_date` DATE NOT NULL,
  `first_payment_date` DATE DEFAULT NULL,
  `last_payment_date` DATE DEFAULT NULL COMMENT 'Fecha real último pago',
  `maturity_date` DATE DEFAULT NULL,
  `status` ENUM('active','paid','defaulted','cancelled','restructured') NOT NULL DEFAULT 'active',
  `balance` DECIMAL(14,2) NOT NULL COMMENT 'Saldo capital actual',
  `total_interest_paid` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_late_fees_paid` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `total_paid` DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  `apply_payment_to` ENUM('capital','interest_first') NOT NULL DEFAULT 'interest_first',
  `notes` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_loans_number` (`loan_number`),
  KEY `idx_loans_client` (`client_id`),
  KEY `idx_loans_assigned` (`assigned_to`),
  KEY `idx_loans_status` (`status`),
  KEY `idx_loans_type` (`loan_type`),
  CONSTRAINT `fk_loans_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`),
  CONSTRAINT `fk_loans_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_loans_created` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- CUOTAS (Tipo A - Amortización nivelada)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `loan_installments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` INT UNSIGNED NOT NULL,
  `installment_number` TINYINT UNSIGNED NOT NULL,
  `due_date` DATE NOT NULL,
  `principal_amount` DECIMAL(12,2) NOT NULL,
  `interest_amount` DECIMAL(12,2) NOT NULL,
  `total_amount` DECIMAL(12,2) NOT NULL,
  `paid_amount` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `paid_principal` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `paid_interest` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `paid_late_fee` DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  `balance_after` DECIMAL(12,2) NOT NULL,
  `status` ENUM('pending','partial','paid','overdue') NOT NULL DEFAULT 'pending',
  `paid_date` DATE DEFAULT NULL,
  `late_fee` DECIMAL(12,2) NOT NULL DEFAULT 0.00 COMMENT 'Mora calculada',
  `days_late` SMALLINT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_inst_loan` (`loan_id`),
  KEY `idx_inst_due` (`due_date`),
  KEY `idx_inst_status` (`status`),
  CONSTRAINT `fk_inst_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- PAGOS (Cabecera)
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payments` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` INT UNSIGNED NOT NULL,
  `payment_number` VARCHAR(20) NOT NULL,
  `payment_date` DATE NOT NULL,
  `total_received` DECIMAL(12,2) NOT NULL,
  `receipt_number` VARCHAR(50) DEFAULT NULL,
  `payment_method` ENUM('cash','transfer','check','other') NOT NULL DEFAULT 'cash',
  `notes` TEXT DEFAULT NULL,
  `registered_by` INT UNSIGNED NOT NULL,
  `voided` TINYINT(1) NOT NULL DEFAULT 0,
  `voided_by` INT UNSIGNED DEFAULT NULL,
  `voided_at` DATETIME DEFAULT NULL,
  `void_reason` VARCHAR(255) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payment_number` (`payment_number`),
  KEY `idx_pay_loan` (`loan_id`),
  KEY `idx_pay_date` (`payment_date`),
  CONSTRAINT `fk_pay_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`),
  CONSTRAINT `fk_pay_registered` FOREIGN KEY (`registered_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- DETALLE DE PAGOS
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payment_items` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `payment_id` INT UNSIGNED NOT NULL,
  `installment_id` INT UNSIGNED DEFAULT NULL,
  `item_type` ENUM('capital','interest','late_fee','other') NOT NULL,
  `amount` DECIMAL(12,2) NOT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pitems_payment` (`payment_id`),
  KEY `idx_pitems_inst` (`installment_id`),
  CONSTRAINT `fk_pitems_payment` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pitems_inst` FOREIGN KEY (`installment_id`) REFERENCES `loan_installments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- LOG DE AUDITORÍA
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_log` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `entity` VARCHAR(50) NOT NULL,
  `entity_id` INT UNSIGNED DEFAULT NULL,
  `old_data` JSON DEFAULT NULL,
  `new_data` JSON DEFAULT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(500) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_entity` (`entity`, `entity_id`),
  KEY `idx_audit_action` (`action`),
  KEY `idx_audit_date` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- CONFIGURACIÓN DEL SISTEMA
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(100) NOT NULL,
  `setting_value` TEXT NOT NULL,
  `setting_type` ENUM('string','integer','decimal','boolean','json') NOT NULL DEFAULT 'string',
  `description` VARCHAR(255) DEFAULT NULL,
  `group` VARCHAR(50) NOT NULL DEFAULT 'general',
  `updated_by` INT UNSIGNED DEFAULT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_settings_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------
-- EVENTOS DE PRÉSTAMO
-- -------------------------------------------------------
CREATE TABLE IF NOT EXISTS `loan_events` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `loan_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED DEFAULT NULL,
  `event_type` ENUM('created','payment','restructured','status_change','note','document') NOT NULL,
  `description` TEXT NOT NULL,
  `meta` JSON DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_events_loan` (`loan_id`),
  CONSTRAINT `fk_events_loan` FOREIGN KEY (`loan_id`) REFERENCES `loans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
